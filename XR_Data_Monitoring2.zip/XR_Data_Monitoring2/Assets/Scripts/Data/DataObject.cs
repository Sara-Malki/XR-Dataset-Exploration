using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataObject : MonoBehaviour
{
    public int id;
    public string category;
    public int value;

    // Les matériaux pour chaque catégorie
    public Material matA;
    public Material matB;
    public Material matC;
    public Material matSelected;

    private Renderer rend;

    void Start()
    {
        rend = GetComponent<Renderer>();
        ApplyCategoryColor();
    }

    void ApplyCategoryColor()
    {
        Renderer r = GetComponent<Renderer>();

        if (category == "A")
            r.material = matA;
        else if (category == "B")
            r.material = matB;
        else if (category == "C")
            r.material = matC;
    }
    public void Select()
    {
        rend.material = matSelected;
    }

    public void Deselect()
    {
        ApplyCategoryColor();
    }
}
