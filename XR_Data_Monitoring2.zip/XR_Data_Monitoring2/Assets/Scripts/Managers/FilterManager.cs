using UnityEngine;
using System.Collections.Generic;

public class FilterManager : MonoBehaviour
{
    private List<DataObject> allObjects = new List<DataObject>();

    public void Register(DataObject obj)
    {
        if (!allObjects.Contains(obj))   // 🛡 sécurité
        {
            allObjects.Add(obj);
        }
    }

    public void ShowAll()
    {
        foreach (DataObject obj in allObjects)
        {
            obj.gameObject.SetActive(true);
        }
    }

    public void FilterByCategory(string category)
    {
        foreach (DataObject obj in allObjects)
        {
            bool visible = obj.category == category;
            obj.gameObject.SetActive(visible);
        }
    }
}
