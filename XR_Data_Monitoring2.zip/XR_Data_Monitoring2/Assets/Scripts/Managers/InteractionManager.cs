using UnityEngine;
using TMPro;   

public class InteractionManager : MonoBehaviour
{
    public Camera mainCamera;
    public TMP_Text infoText;   

    private DataObject selectedObject;

    void Start()
    {
        infoText.text = "Sélectionnez un cube";
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) // clic gauche souris
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                DataObject dataObj = hit.collider.GetComponent<DataObject>();

                if (dataObj != null)
                {
                    SelectObject(dataObj);
                }
            }
        }
    }

    void SelectObject(DataObject obj)
    {
        // Désélectionner l'ancien cube
        if (selectedObject != null)
        {
            selectedObject.Deselect();
        }

        // Sélectionner le nouveau
        selectedObject = obj;
        selectedObject.Select();

        // Affichage TextMeshPro
        infoText.text =
            $"ID : {obj.id}\n" +
            $"Catégorie : {obj.category}\n" +
            $"Valeur : {obj.value}";
    }
}
