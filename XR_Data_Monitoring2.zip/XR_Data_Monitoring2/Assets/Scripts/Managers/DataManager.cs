using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public GameObject dataPrefab;          // Prefab DataObject
    public List<DataObject> dataObjects;    // Liste des objets créés
    FilterManager filterManager;

    void Start()
    {
        filterManager = FindObjectOfType<FilterManager>();
        LoadCSV();
    }

    void LoadCSV()
    {
        dataObjects = new List<DataObject>();

        // Charger le fichier CSV depuis Resources/Data
        TextAsset csvFile = Resources.Load<TextAsset>("Data/dataset");

        if (csvFile == null)
        {
            Debug.LogError("CSV non trouvé !");
            return;
        }

        string[] lines = csvFile.text.Split('\n');

        // On commence à 1 pour ignorer l’en-tête
        for (int i = 1; i < lines.Length; i++)
        {
            if (string.IsNullOrWhiteSpace(lines[i])) continue;

            string[] values = lines[i].Split(',');

            GameObject obj = Instantiate(dataPrefab);
            obj.transform.position = new Vector3((i % 4) * 2, 0.5f, (i / 4) * 2);

            DataObject data = obj.GetComponent<DataObject>();
            data.id = int.Parse(values[0]);
            data.category = values[1];
            data.value = int.Parse(values[2]);
            dataObjects.Add(data);
            filterManager.Register(data);
        }
    }
}
